// background.js
chrome.runtime.onInstalled.addListener(() => {
  console.log('Eklenti yüklendi.');
});
