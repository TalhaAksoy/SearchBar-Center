document.addEventListener('DOMContentLoaded', () => {
    // Load saved options
    browser.storage.sync.get(['option1', 'option2'], (result) => {
        document.getElementById('option1').value = result.option1 || '';
        document.getElementById('option2').value = result.option2 || '';
    });

    // Save options
    document.getElementById('save').addEventListener('click', () => {
        const option1 = document.getElementById('option1').value;
        const option2 = document.getElementById('option2').value;

        browser.storage.sync.set({
            option1: option1,
            option2: option2
        }, () => {
            alert('Options saved!');
        });
    });
});